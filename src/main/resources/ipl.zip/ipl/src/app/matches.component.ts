import { Component,OnInit } from '@angular/core';
import {Match} from './match';
import {MatchService} from './match.service';
import {Router} from '@angular/router';
import {Response} from './response';
import {Observable} from 'rxjs/Observable';
import {PagerService} from './pager.service';

@Component({
  selector: 'ipl-matches',
  templateUrl: './matches.component.html',
  styleUrls: ['./matches.component.css'],
  providers: [MatchService,PagerService]
})


export class MatchesComponent implements OnInit{
  title = 'Indian Premier League';
  matches : Match[];
  matchResponse: Response;
  pager: any = {};
  pagedItems: Match[];
  values = [10,20,30,50,100];
  selectedPageSize = 10;

  ngOnInit(): void{
    this.setPage(1);
  }

  constructor(private matchService: MatchService,
    private router:Router,private pagerService:PagerService){}

	getMatches(size:number,page:number): void{
		this.matchService.getMatches(size,page-1).then(response => 
      {

        this.matchResponse = response;
        this.matches = response.content;
        this.pager = this.pagerService.getPager(this.matchResponse.totalElements,page-1,this.selectedPageSize);
      });
	}

  setPage(page:number):void{
    if(page < 1 || page > this.pager.totalPages){
      return ;
    }
    this.getMatches(this.selectedPageSize,page);
    /*this.pager = this.pagerService.getPager(this.matchResponse.totalElements,page);
    this.pagedItems = this.matches.slice(this.pager.startIndex, this.pager.endIndex+1);*/
  }

  goToDetail(match:Match): void{
    this.router.navigate(['/detail',match.id]);
  }

}
