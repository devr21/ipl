import {Injectable} from '@angular/core';
import {Match} from './match';
import {Headers,Http} from '@angular/http';
import 'rxjs/add/operator/toPromise';
import {Response} from './response';

@Injectable()
export class MatchService{

	private matchesUrl = 'http://localhost:8080/match';

	constructor(private http:Http){}

	getMatches(size:number,page:number): Promise<Response> {
		return this.http.get(this.matchesUrl+"?size="+size+"&page="+page)
		.toPromise()
		.then(response => response.json() as Response)
		.catch(this.handleError);
	}

	private handleError(error: any): Promise<any> {
		console.error('An Error Occurred', error);
		return Promise.reject(error.message || error);
	}

	getMatch(id:number): Promise<Match> {
		const url = `${this.matchesUrl}/${id}`;
		return this.http.get(url)
		.toPromise()
		.then(response => response.json() as Match)
		.catch(this.handleError);
	}
}