import {FormsModule} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {MatchDetailComponent} from './match-detail.component';
import { AppComponent } from './app.component';
import {MatchesComponent} from './matches.component';
import {MatchService} from './match.service';
import {AppRoutingModule} from './app-routing.module';
import {DashboardComponent} from './dashboard.component';
import {HttpModule} from '@angular/http';

@NgModule({
  declarations: [
    AppComponent,
    MatchDetailComponent,
    MatchesComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [MatchService],
  bootstrap: [AppComponent]
})
export class AppModule { }
