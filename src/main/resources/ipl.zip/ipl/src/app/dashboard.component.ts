import {Component, OnInit} from '@angular/core';
import {Match} from './match';
import {MatchService} from './match.service';

@Component({
	selector:'dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.css'] 
})

export class DashboardComponent implements OnInit{
	
	matches: Match[] = [];
	constructor(private matchService:MatchService){}

	ngOnInit(): void{
		this.matchService.getMatches(10,0)
			.then(response => this.matches = response.content.splice(1,5));
	}	

}