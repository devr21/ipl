import {Component,Input,OnInit} from '@angular/core';
import {MatchService} from './match.service';
import {Location} from '@angular/common';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {Match} from './match';
import 'rxjs/add/operator/switchMap';

@Component({
	selector: 'match-detail',
	templateUrl: './match-detail.component.html',
	styleUrls: ['./match-detail.component.css'] 
})



export class MatchDetailComponent implements OnInit{
	
	@Input() match: Match;

	constructor(private matchService: MatchService,
		private route: ActivatedRoute,
		private location: Location){}

	ngOnInit(): void{
		this.route.paramMap
		.switchMap((params: ParamMap) =>
		this.matchService.getMatch(+params.get('id')))
.subscribe(match => this.match = match);
	}

	goBack(): void{
		this.location.back();
	}
}