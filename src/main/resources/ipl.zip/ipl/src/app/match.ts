export class Match{
	id: number;
	team1: string;
	team2: string;
	season: string;
	date: string;
	city: string;
	tossWinner: string;
	tossDecision: string;
	result: string;
	winner: string;
	dlApplied: number;
	winByRuns: number;
	winByWickets: number;
	playerOfMatch: string;
	venue: string;
	umpire1: string;
	umpire2: string;
	umpire3: string;
}
