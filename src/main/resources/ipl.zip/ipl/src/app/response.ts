import {Match} from './match';
import {Sort} from './sort';

export class Response{
	content: Match[];
	last: boolean;
	totalElements:number;
	totalPages:number;
	size:number;
	number:number;
	sort:Sort;
	first:boolean;
	numberOfElements:number;
}