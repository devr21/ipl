package ts.clustering.mdl;

import java.util.Arrays;

import javax.swing.JFrame;

public class DrawGraph {

	public static void create(double[] ts) {
		
		Double[] data = new Double[ts.length];
		int i = 0;
		for(double d:ts)
			data[i++] = d;
		Graph g = new Graph(Arrays.asList(data));
		
		JFrame frame = new JFrame("Time Series");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(g);
		frame.pack();
		frame.setLocationByPlatform(true);
		frame.setVisible(true);
		
	}
	
}
