package ts.clustering.mdl;

public class MKMotif {

	Result motifDiscovery(double[] ts,int len,boolean[]  mark) {
		
		double ed = Integer.MAX_VALUE;
		Motif a = new Motif(len);
		Motif b = new Motif(len);
		double max = Integer.MIN_VALUE;
		
		for(int i=0;i<ts.length-len;++i) {
			if(mark[i]) {
				//System.out.println("first loop: "+mark[i]);
				continue;
			}
			boolean outerFlag = true;
			for(int j=i+1;j<=ts.length-len;++j) {
				if(mark[j]) {
					//System.out.println("j loop: "+mark[j]);
					continue;
				}
				double temp = 0;
				boolean innerFlag = true;
				for(int l=0;l<len;l++) {
					if(mark[i+l]) {
						outerFlag = false;
						break;
					}
					if(mark[j+l]) {
						innerFlag = false;
						break;
					}
					temp += Math.pow((ts[i+l]-ts[j+l]), 2);
				}
				if(!outerFlag)
					break;
				if(innerFlag) {
					temp = Math.sqrt(temp);
					//ed = ed<=temp?ed:temp;
					if(ed > temp) {
						ed = temp;
						a.setStart(i);
						b.setStart(j);
						//System.out.println("found new i: "+i+" j: "+j);
						//System.out.println("euclidean distance: "+ed);
					}
					if(temp > max)
						max = temp;
					}
					//System.out.println("i: "+i+" j: "+j);
			}
		}
		
		return new Result(a,b);
	}
	
	class Result {
		private Motif sequenceA;
		private Motif sequenceB;
		
		public Result(Motif sequenceA,Motif sequenceB) {
			this.sequenceA = sequenceA;
			this.sequenceB = sequenceB;
		}
		
		public Motif getSequenceA() {
			return this.sequenceA;
		}
		
		public Motif getSequenceB() {
			return this.sequenceB;
		}
	}
	
}
