package ts.clustering.mdl;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import ts.clustering.mdl.Cluster.Sequence;
import ts.clustering.mdl.MKMotif.Result;

public strictfp class LaunchPoint {

	public static void main(String[] args) throws  FileNotFoundException {
		
		new LaunchPoint().start();
	}
	
	private void start() throws FileNotFoundException {
		Scanner sc = new Scanner(new FileReader("data.txt")); 
		List<Float> data = new ArrayList<Float>();
		
		while(sc.hasNext()) {
			String val = sc.next();
			//System.out.println(val+" parsed value: "+Float.valueOf(val));
			data.add(Float.valueOf(val));
		}
		
		double[] ts = data.stream().mapToDouble(f -> 
			f != null?(double)Math.round(f*Math.pow(10, 7))/Math.pow(10, 7):Float.NaN).toArray();
		
		data = null;
		
		DrawGraph.create(ts);
		
		boolean[] mark = new boolean[ts.length];
		
		List<Cluster> clusters = new ArrayList<Cluster>();
		MKMotif mk = new MKMotif();
		double bitsave;
		do {
			bitsave = 0;
			for(int k=50;k<80;k+=5) {
				MKMotif.Result result =  mk.motifDiscovery(ts, k,mark);
				setMark(mark,result);
				//printArray(mark);
				Cluster temp = createCluster(ts,result);
				
				//DrawGraph.create(temp.getSequences().get(0).getSeq());
				//DrawGraph.create(temp.getSequences().get(1).getSeq());
				double comb[] = new double[ts.length];
				int val = result.getSequenceA().getStart();
				for(int i=val;i<val+k;++i) 
					comb[i] = ts[i];
				val = result.getSequenceB().getStart();
				for(int i=val;i<val+k;++i)
					comb[i] = ts[i];
				
				//DrawGraph.create(comb);
				
				bitsave += computeBitsave(temp);
				System.out.println("bitsave: "+bitsave);
				/*try {
					Thread.currentThread().join();
				}catch(Exception e) {
					
				}*/
				clusters.add(temp);
			}
			
			/*
			 *  Add Operator
			 */
			
			Iterator<Cluster> it = clusters.iterator();
			while(it.hasNext()) {
				Cluster c = it.next();
				Sequence a = nearestNeighbor(ts,c.getCenter().getSeq());
				double[] normA = dNorm(a.getSeq());
				
				int mdlOld = mdlCluster(c)/c.getCenter().getSeq().length;
				c.setSize(c.getSize()+1);
				double[] center = c.getCenter().getSeq();
				for(int i=0;i<a.getSeq().length;++i) 
					center[i] = Math.round((center[i]*(c.getSize()-1) + normA[i])/(c.getSize())); 
				c.addSequence(a);
				c.setCenter(new Sequence(center));
				c.setShift(new int[c.getSize()]);
				//DrawGraph.create(a.getSeq());
				int mdlNew = mdlCluster(c);
				
				double[] temp = new double[c.getCenter().getSeq().length];
				
				for(int i=a.getStart(),j = 0;i<a.getStart()+c.getCenter().getSeq().length;++i,j++) 
					temp[j] = ts[i];
				
				
				int mdlOld2 = mdl(dNorm(temp))/c.getCenter().getSeq().length;
				
				
				System.out.println("final bs: "+(mdlNew-mdlOld - mdlOld2));
				bitsave += (mdlNew - mdlOld - mdlOld2);
			}
			
			try {
				Thread.currentThread().join();
			}catch(Exception e) {
				
			}
			
		}while(bitsave > 0);
		
		
		sc.close();
	}
	
	private Sequence nearestNeighbor(double[] ts, double[] c) {
		Sequence seq = null;
		double ed = Integer.MAX_VALUE;
		int index = 0;
		double[] temp = new double[c.length];
		for(int i=0;i<ts.length-c.length;++i) {
			
			for(int j=0;j<c.length;j++) 
				temp[j] = ts[i+j];
			
			double val = ed(c,dNorm(temp));
			if(val < ed) {
				ed = val;
				index = i;
			}
			
		}
		seq = new Sequence(temp);
		seq.setStart(index);
		return seq;
	}
	
	private double ed(double[] a, double[] b) {
		
		double temp = 0;
		
		for(int i=0;i<a.length;++i) 
			temp += Math.pow((a[i]-b[i]), 2);
		temp = Math.sqrt(temp);
		
		return temp;
	}
	
	private Cluster createCluster(double[] ts,Result result) {
		int val = result.getSequenceA().getStart();
		//System.out.println("seqA start point: "+val);
		Sequence seqA = new Sequence(Arrays.copyOfRange(ts, val, val+result.getSequenceA().getLength()));
		seqA.setStart(val);
		val = result.getSequenceB().getStart();
		//System.out.println("seqB start point: "+val);
		Sequence seqB = new Sequence(Arrays.copyOfRange(ts, val, val+result.getSequenceB().getLength()));
		seqB.setStart(val);
		Cluster c = new Cluster();
		c.addSequence(seqA);
		c.addSequence(seqB);
		c.setSize(2);
		
		double[] a = dNorm(seqA.getSeq());
		double[] b = dNorm(seqB.getSeq());
		double[] temp = new double[a.length];
		for(int i=0;i<a.length;i++) 
			temp[i] = Math.round((a[i]+b[i])/2);
		c.setCenter(new Sequence(temp));
		c.setShift(new int[c.getSize()]);
		//System.out.println("cluster is created: "+c.getSize());
		return c;
	}

	/*
	 * with fixed value of b 
	 */
	private double[] dNorm(double[] seq) {
		int val = 1 << 6;
		double min = Integer.MAX_VALUE;
		double max = Integer.MIN_VALUE;
		for(double d:seq) {
			min = min>d?d:min;
			max = max<d?d:max;
		}
		for(int i=0;i<seq.length;i++) 
			seq[i] = Math.round(((seq[i] - min)/(max - min))*(val - 1)+1);
		return seq;
	}
	
	private void printArray(boolean[] arr) {
		for(boolean a:arr)
			System.out.print(a+" ");
		System.out.println();
	}
	
	private int mdlCluster(Cluster c) {
		int mdl = 0;
		int mdlCent = mdl(c.getCenter().getSeq());
		int maxMdl = Integer.MIN_VALUE;
		int costDiff = 0;
		
		for(int i=0;i<c.getSize();++i) {
			double[] temp = dNorm(c.getSequences().get(i).getSeq());
			
			int mdlDiff = mdl(temp,c.getCenter().getSeq());
			maxMdl = Math.max(mdlDiff, maxMdl);
			costDiff += mdlDiff;
		}
		costDiff -= maxMdl;
		mdl = mdlCent + costDiff;
		System.out.println("mdl: "+mdl);
		return mdl;
	}
	
	private int computeBitsave(Cluster c) {
		double[] seqA = dNorm(c.getSequences().get(0).getSeq());
		double[] seqB = dNorm(c.getSequences().get(1).getSeq());
		
		int diffA = mdl(seqA,c.getCenter().getSeq());
		int diffB = mdl(seqB,c.getCenter().getSeq());
		
		int mdlOld = (mdl(seqA)+mdl(seqB))/seqA.length;
		int mdlNew = mdl(c.getCenter().getSeq()) + Math.min(diffA, diffB)/seqA.length;
		//System.out.println("mdlOld: "+mdlOld+" mdlNew: "+mdlNew);
		return mdlNew - mdlOld;
	}
	
	private int mdl(double[] seq) {
		double min = Integer.MAX_VALUE;
		double max = Integer.MIN_VALUE;
		for(int i=0;i<seq.length;++i){
			min = min>seq[i]?seq[i]:min;
			max = max<seq[i]?seq[i]:max;
		}
		return bitcost(seq,min,max);
	}
	
	private int mdl(double[] seq,double[] center) {
		double min = Integer.MAX_VALUE;
		double max = Integer.MIN_VALUE;
		for(int i=0;i<seq.length;++i){
			seq[i] = seq[i] - center[i];
			min = min>seq[i]?seq[i]:min;
			max = max<seq[i]?seq[i]:max;
		}
		
		return bitcost(seq,min,max);
	}
	
	private int bitcost(double[] seq,double min, double max) {
		for(int i=0;i<seq.length;i++) {
			seq[i] = seq[i] - min +1;
		}
		return entropy(seq);
	}
	
	private int entropy(double[] localSeq) {
		
		double entropy = 0;
		Map<Integer,Integer> values = new HashMap<Integer,Integer>();
		for(double d:localSeq) 
			if((int)d != 0)
				if(values.containsKey((int)d))
					values.put((int)d, values.get((int)d)+1);
				else
					values.put((int)d, 1);
		
		for(double d:localSeq) {
			double p = 0;
			try {
				p = (double)values.get((int)d)/localSeq.length;
			}
			catch(NullPointerException e) {
				
			}
			//System.out.println("probability: "+p+" for d: "+d+" and entropy value: "+Math.log10(p)/Math.log10(2)*p);
			if(p != 0.0)
				entropy += -p*Math.log10(p)/Math.log10(2);
			//System.out.println("entropy: "+entropy);
		}
		//final double probX =(double) 1/(localSeq.length); 
		//entropy = -localSeq.length*(probX * (Math.log10(probX)/Math.log10(2)));
		//System.out.println("SequenceDl: "+entropy*localSeq.length);
		return (int) (entropy*localSeq.length);
		
	}
	
	private double computeDL(Sequence seq) {
		double[] localSeq = seq.getSeq();
		double entropy = 0;
		Map<Integer,Integer> values = new HashMap<Integer,Integer>();
		for(double d:localSeq) 
			if((int)d != 0)
				if(values.containsKey((int)d))
					values.put((int)d, values.get((int)d)+1);
				else
					values.put((int)d, 1);
		
		for(double d:localSeq) {
			double p = 0;
			try {
				p = (double)values.get((int)d)/localSeq.length;
			}
			catch(NullPointerException e) {
				
			}
			//System.out.println("probability: "+p+" for d: "+d+" and entropy value: "+Math.log10(p)/Math.log10(2)*p);
			if(p != 0.0)
				entropy += -p*Math.log10(p)/Math.log10(2);
			//System.out.println("entropy: "+entropy);
		}
		//final double probX =(double) 1/(localSeq.length); 
		//entropy = -localSeq.length*(probX * (Math.log10(probX)/Math.log10(2)));
		System.out.println("SequenceDl: "+entropy*localSeq.length);
		return entropy*localSeq.length;
	}
	
	private double computeDL(Cluster c) {
		double centerDL = computeDL(c.getCenter()); 
		double maxOfClusterSeq = 0;
		double total = 0;
		double[] center = c.getCenter().getSeq();
		
		for(Sequence s:c.getSequences()) {
			double[] temp = s.getSeq();
			for(int i=0;i<temp.length;++i) { 
				//System.out.println("difference: "+(temp[i] - center[i]));
				temp[i] = Math.abs(temp[i] - center[i]);
				
			}
			double localDL = computeDL(new Sequence(temp));
			maxOfClusterSeq = maxOfClusterSeq>localDL?maxOfClusterSeq:localDL;
			total += localDL;
		}
		
		double finalClusterDL = centerDL - maxOfClusterSeq + total;
		//System.out.println("cluster DL: "+finalClusterDL);
		return finalClusterDL;
	}

	private void setMark(boolean[] mark, Result result) {
		int val = result.getSequenceA().getStart();
		//System.out.println("value of i: "+val);
		for(int i=val;i<val+result.getSequenceA().getLength();i++) 
			mark[i++] = true;
		val = result.getSequenceB().getStart();
		//System.out.println("value of index of b: "+val);
		for(int i=val;i<val+result.getSequenceB().getLength();i++)
			mark[i++] = true;
		
	}
	
}
