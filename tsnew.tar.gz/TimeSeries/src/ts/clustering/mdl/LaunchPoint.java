package ts.clustering.mdl;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import ts.clustering.mdl.Cluster.Sequence;
import ts.clustering.mdl.MKMotif.Result;

public strictfp class LaunchPoint {

	public static void main(String[] args) throws  FileNotFoundException {
		
		new LaunchPoint().start();
	}
	
	private void start() throws FileNotFoundException {
		Scanner sc = new Scanner(new FileReader("data.txt")); 
		List<Float> data = new ArrayList<Float>();
		
		while(sc.hasNext()) {
			String val = sc.next();
			System.out.println(val+" parsed value: "+Float.valueOf(val));
			data.add(Float.valueOf(val));
		}
		
		double[] ts = data.stream().mapToDouble(f -> 
			f != null?(double)Math.round(f*Math.pow(10, 7))/Math.pow(10, 7):Float.NaN).toArray();
		
		data = null;
		
		DrawGraph.create(ts);
		
		boolean[] mark = new boolean[ts.length];
		
		Cluster cluster = new Cluster();
		Cluster comp = new Cluster();
		MKMotif mk = new MKMotif();
		double bitsave;
		do {
			bitsave = 0;
			for(int k=50;k<80;k+=5) {
				MKMotif.Result result =  mk.motifDiscovery(ts, k,mark);
				setMark(mark,result);
				//printArray(mark);
				Cluster temp = createCluster(ts,result);
				
				//DrawGraph.create(temp.getSequences().get(0).getSeq());
				//DrawGraph.create(temp.getSequences().get(1).getSeq());
				/*try {
				Thread.currentThread().join();
				}catch(Exception e) {
					
				}*/
				bitsave += computeBitsave(temp,temp.getSequences().get(0),temp.getSequences().get(1));
				System.out.println("bitsave: "+bitsave);
			}
			
		}while(bitsave > 0);
		
		
		sc.close();
	}
	
	private Cluster createCluster(double[] ts,Result result) {
		int val = result.getSequenceA().getStart();
		Sequence seqA = new Sequence(Arrays.copyOfRange(ts, val, val+result.getSequenceA().getLength()));
		val = result.getSequenceB().getStart();
		Sequence seqB = new Sequence(Arrays.copyOfRange(ts, val, val+result.getSequenceB().getLength()));
		
		Cluster c = new Cluster();
		c.addSequence(seqA);
		c.addSequence(seqB);
		c.setSize(2);
		
		double[] a = seqA.getSeq();
		double[] b = seqB.getSeq();
		double[] temp = new double[a.length];
		for(int i=0;i<a.length;i++) 
			temp[i] = (a[i]+b[i])/2;
		c.setCenter(new Sequence(temp));
		c.setShift(new int[c.getSize()]);
		//System.out.println("cluster is created: "+c.getSize());
		return c;
	}

	private void printArray(boolean[] arr) {
		for(boolean a:arr)
			System.out.print(a+" ");
		System.out.println();
	}
	
	private double computeBitsave(Cluster c,Sequence a, Sequence b) {
		double bs = computeDL(a)+computeDL(b) - computeDL(c);
		
		//System.out.println(bs);
		return bs;
	}
	
	
	private double computeDL(Sequence seq) {
		double[] localSeq = seq.getSeq();
		double entropy = 0;
		final double probX =(double) 1/(localSeq.length); 
		
		entropy = -localSeq.length*(probX * (Math.log10(probX)/Math.log10(2)));
		//System.out.println("SequenceDl: "+entropy*localSeq.length);
		return entropy*localSeq.length;
	}
	
	private double computeDL(Cluster c) {
		double centerDL = computeDL(c.getCenter()); 
		double maxOfClusterSeq = 0;
		double total = 0;
		double[] center = c.getCenter().getSeq();
		for(Sequence s:c.getSequences()) {
			double[] temp = s.getSeq();
			for(int i=0;i<temp.length;++i) 
				temp[i] = Math.abs(temp[i] - center[i]);
			
			double localDL = computeDL(new Sequence(temp));
			maxOfClusterSeq = maxOfClusterSeq>localDL?maxOfClusterSeq:localDL;
			total += localDL;
		}
		double finalClusterDL = centerDL - maxOfClusterSeq + total;
		//System.out.println("cluster DL: "+finalClusterDL);
		return finalClusterDL;
	}

	private void setMark(boolean[] mark, Result result) {
		int val = result.getSequenceA().getStart();
		//System.out.println("value of i: "+val);
		for(int i=val;i<val+result.getSequenceA().getLength();i++) 
			mark[i++] = true;
		val = result.getSequenceB().getStart();
		//System.out.println("value of index of b: "+val);
		for(int i=val;i<val+result.getSequenceB().getLength();i++)
			mark[i++] = true;
		
	}
	
}
