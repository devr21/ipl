package ts.clustering.mdl;

import java.util.ArrayList;
import java.util.List;

public class Cluster {

	private int size;
	private Sequence center;
	private List<Sequence> sequences;
	private int[] shift;
	private int minM;
	private int maxM;
	private int cenM;
	
	public int getMinM() {
		return minM;
	}

	public void setMinM(int minM) {
		this.minM = minM;
	}

	public int getMaxM() {
		return maxM;
	}

	public void setMaxM(int maxM) {
		this.maxM = maxM;
	}

	public int getCenM() {
		return cenM;
	}

	public void setCenM(int cenM) {
		this.cenM = cenM;
	}

	public int[] getShift() {
		return shift;
	}

	public void setShift(int[] shift) {
		this.shift = shift;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Sequence getCenter() {
		return center;
	}

	public void setCenter(Sequence center) {
		this.center = center;
	}

	public List<Sequence> getSequences() {
		return sequences;
	}

	public void setSequences(List<Sequence> sequences) {
		this.sequences = sequences;
	}
	
	public void addSequence(Sequence seq) {
		if(this.sequences == null)
			this.sequences = new ArrayList<Sequence>();
		this.sequences.add(seq);
	}
	
	public boolean equals(Cluster c) {
		
		if(this.size == c.getSize())
			if(this.center.equals(c.getCenter()))
				return true;
		
		return false;
	}

	static class Sequence{
		private double[] seq;
		private int start;
		
		public void setStart(int start) {
			this.start = start;
		}
		
		public int getStart() {
			return this.start;
		}
		
		public Sequence(double[] seq) {
			this.seq = seq;
		}
		
		public double[] getSeq() {
			return this.seq;
		}
		
		public boolean equals(Sequence seq) {
			
			if(this.start == seq.getStart()) {
				double[] s = seq.getSeq();
				for(int i=0;i<this.seq.length;i++) {
					if(this.seq[i] != s[i])
						return false;
				}
			}
			else
				return false;
			
			return true;
		}
		
	}
}
