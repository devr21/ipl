package ts.clustering.mdl;

public class Motif{
	private int len;
	private int start;
	
	public Motif(int len) {
		this.len = len;
	}
	
	public int getLength() {
		return this.len;
	}
	
	public int getStart() {
		return this.start;
	}
	
	public void setStart(int start) {
		this.start = start;
	}
}
