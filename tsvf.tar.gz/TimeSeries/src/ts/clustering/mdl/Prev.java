package ts.clustering.mdl;

import java.util.Arrays;

public class Prev {
/*	for(int off = 0;off<c2.getCenter().getSeq().length;off++) {
		int upper = Math.min(off+c2.getCenter().getSeq().length,c1.getCenter().getSeq().length );
		double[] center1 = new double[upper - off];
		System.out.println("upper: "+upper+" off: "+off);
		for(int i=off;i<upper-off;i++) 
			center1[i] = cen1.getSeq()[i];
		if(upper-off > off)
		center1 = Arrays.copyOfRange(cen1.getSeq(), off, upper-off);
		upper = Math.min(c1.getCenter().getSeq().length - off, c2.getCenter().getSeq().length);
		double[] center2 = new double[upper];
		for(int i=0;i<upper-off;++i)
			center2[i] = c2.getCenter().getSeq()[i];
		center2 = Arrays.copyOfRange(cen2.getSeq(), 0, upper-off);
		System.out.println("center1 length: "+center1.length+" center2 length: "+center2.length);
		
		double[] centerF = new double[center1.length];
		for(int i=0;i<center1.length;i++)
			centerF[i] = (center1[i]*c1.getSize() + center2[i]*c2.getSize())/(c1.getSize()+c2.getSize());
		
		int mCen = centerF.length;
		int m1 = c1.getCenter().getSeq().length;
		int m2 = c2.getCenter().getSeq().length;
		double[] part1 = new double[off+1];
		if(m1 > mCen) {
			for(int i=0;i<off;i++)
				part1[i] = c1.getCenter().getSeq()[i];
			part1 = Arrays.copyOfRange(c1.getCenter().getSeq(), 0, off);
		}
		double[] part2 = null;
		if(m1 > m2+off+1) {
			part2 = new double[m1-m2-off-1];
			part2 = Arrays.copyOfRange(cen1.getSeq(), m2+off, m1);
		}
		else {
			part2 = new double[m2-m1+off-1];
			part2 = Arrays.copyOfRange(cen2.getSeq(), m1-off, m2);
		}
		
		double temp[] = new double[part1.length+part2.length+centerF.length];
		int i=0;
		for(;i<part1.length;i++)
			temp[i] = part1[i];
		for(;i<centerF.length+part1.length;i++)
			temp[i] = centerF[i-part1.length];
		for(;i<temp.length;i++)
			temp[i] = part2[i-centerF.length-part1.length];
		
		double ed = ed(center1,center2);
		System.out.println(ed);
	}*/
	
}
