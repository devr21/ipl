package ts.clustering.mdl;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import ts.clustering.mdl.Cluster.Sequence;
import ts.clustering.mdl.MKMotif.Result;

public strictfp class LaunchPoint {

	public static void main(String[] args) throws  FileNotFoundException {
		
		new LaunchPoint().start();
	}
	
	private void start() throws FileNotFoundException {
		Scanner sc = new Scanner(new FileReader("data.txt")); 
		List<Float> data = new ArrayList<Float>();
		while(sc.hasNext()) {
			String val = sc.next();
			//System.out.println(val+" parsed value: "+Float.valueOf(val));
			data.add(Float.valueOf(val));
		}
		double[] ts = data.stream().mapToDouble(f -> 
			f != null?(double)Math.round(f*Math.pow(10, 7))/Math.pow(10, 7):Float.NaN).toArray();
		data = null;
		DrawGraph.create(ts,"Time Series");
		boolean[] mark = new boolean[ts.length];
		List<Cluster> clusters = new ArrayList<Cluster>();
		MKMotif mk = new MKMotif();
		double bitsave;
		do {
			bitsave = 0;
			for(int k=50;k<=80;k+=5) {
				MKMotif.Result result =  mk.motifDiscovery(ts, k,mark);
				setMark(mark,result);
				//printArray(mark);
				Cluster temp = createCluster(ts,result);
				
				bitsave += computeBitsave(temp);
				System.out.println("bitsave: "+bitsave);
				clusters.add(temp);
			}
			/*
			 *  Add Operator
			 */
			Iterator<Cluster> it = clusters.iterator();
			int count = 1;
			while(it.hasNext()) {
				Cluster c = it.next();
				Sequence a = nearestNeighbor(ts,c.getCenter().getSeq(),mark);
				if(a != null) {
					double[] normA = dNorm(a.getSeq())/*a.getSeq()*/;
					
					//DrawGraph.create(a.getSeq(), "Added seq ");
					
					int mdlOld = mdlCluster(c)/c.getCenter().getSeq().length;
					c.setSize(c.getSize()+1);
					double[] center = c.getCenter().getSeq();
					
					//DrawGraph.create(center, "Center before update");
					
					for(int i=0;i<a.getSeq().length;++i) 
						center[i] = Math.round((center[i]*(c.getSize()-1) + normA[i])/(c.getSize())); 
					c.addSequence(a);
					//DrawGraph.create(center, "Center after update");
					c.setCenter(new Sequence(center));
					c.setShift(new int[c.getSize()]);
					int mdlNew = mdlCluster(c);
					
					double[] temp = new double[c.getCenter().getSeq().length];
					
					for(int i=a.getStart(),j = 0;i<a.getStart()+c.getCenter().getSeq().length;++i,j++) 
						temp[j] = ts[i];
					
					
					int mdlOld2 = mdl(dNorm(temp))/c.getCenter().getSeq().length;
					
					
					System.out.println("final bs: "+(mdlNew-mdlOld - mdlOld2));
					bitsave += (mdlNew - mdlOld - mdlOld2);
				}
			}
			/*for(int i=0;i<clusters.size();++i) {
				if(i == 5) {
					DrawGraph.create(clusters.get(i).getCenter().getSeq(),"center");
					int counter = 1;
					for(Sequence s:clusters.get(i).getSequences())
						DrawGraph.create(s.getSeq(),"Sequence "+(counter++));
				}
			}*/
			
			/*
			 * Merge Operation
			 */
			int bs = Integer.MAX_VALUE;
			if(clusters.size() >= 2) {
				List<Cluster> fin = new ArrayList<Cluster>();
				
				int bsmdl = Integer.MAX_VALUE;
				int index = 0;
				for(Cluster c1:clusters) {
					Sequence cen1 = c1.getCenter();
					int bsed = Integer.MAX_VALUE;
					
					for(int j=index+1;j<clusters.size();++j) {
						Cluster c2 = clusters.get(j);
						Sequence cen2 = clusters.get(j).getCenter();
						if(cen2.equals(cen1))
							continue;
						Cluster tempCluster = new Cluster();
						tempCluster.setSequences(c1.getSequences());
						for(Sequence s:c2.getSequences())
							tempCluster.addSequence(s);
						//System.out.println("size of merged cluster: "+tempCluster.getSequences().size());
						tempCluster.setSize(c1.getSize()+c2.getSize());
						int n1 = c1.getSize(),n2 = c2.getSize();
						int m1 = c1.getCenter().getSeq().length, m2 = c2.getCenter().getSeq().length;
//Off Point			
						for(int off = 0;off < m1;off++) {
							double[] ts1 = Arrays.copyOfRange(cen1.getSeq(), off+1, Math.min(m1, m2+off));
							double[] ts2 = Arrays.copyOfRange(cen2.getSeq(), 0, Math.min(m1-off, m2));
							int cenL = 0;
							if(ts1.length > ts2.length)
								cenL = ts1.length;
							else
								cenL = ts2.length;
							double[] newCen = new double[cenL];
							for(int i=0;i<cenL;i++) {
								double t = ts2[i];
								newCen[i] = (ts1[i]*n1 + ts2[i]*n2)/(n1+n2);
							}
							int mCen = newCen.length;
							double part1[] = null ;
							double[] part2;
							if(m1>mCen)
								part1 = Arrays.copyOfRange(cen1.getSeq(), 0, off);
							if(m1 > m2+off)
								part2 = Arrays.copyOfRange(cen1.getSeq(), m2+off+1, m1);
							else
								part2 = Arrays.copyOfRange(cen2.getSeq(), m1-off, m2);
							
							double ed = ed(ts1,ts2);
							newCen = mergeArraysInOrder(part1,newCen,part2);
							
							int costmdl = mergeCluster(tempCluster,c1,c2,newCen);
							if(bsmdl > costmdl) {
								bsmdl = costmdl;
								fin.add(tempCluster);
							}
						}
						
						for(int off = 0;off < m2;off++) {
							double[] ts1 = Arrays.copyOfRange(cen1.getSeq(), 0, Math.min(m1, m2-off));
							double[] ts2 = Arrays.copyOfRange(cen2.getSeq(), off+1, Math.min(m1+off, m2));
							int cenL = 0;
							if(ts1.length > ts2.length)
								cenL = ts1.length;
							else
								cenL = ts2.length;
							double[] newCen = new double[cenL];
							for(int i=0;i<cenL;i++)
								newCen[i] = (ts1[i]*n1 + ts2[i]*n2)/(n1+n2); /* array index due to ts1 or ts2*/
							int mCen = newCen.length;
							double part1[] = null ;
							double[] part2;
							if(m2>mCen)
								part1 = Arrays.copyOfRange(cen2.getSeq(), 0, off);
							if(m2 > m1+off)
								part2 = Arrays.copyOfRange(cen2.getSeq(), m1+off+1, m2);
							else
								part2 = Arrays.copyOfRange(cen1.getSeq(), m2-off, m1);
							
							double ed = ed(ts1,ts2);
							newCen = mergeArraysInOrder(part1,newCen,part2);
							
							int costmdl = mergeCluster(tempCluster,c1,c2,newCen);
							if(bsmdl > costmdl) {
								bsmdl = costmdl;
								fin.add(tempCluster);
							}
						}
						
					}
					
					if(bsed == Integer.MAX_VALUE)
						continue;
					
					index++;
				}
				bs = bsmdl;
			}
			
			try {
				Thread.currentThread().join();
			}catch(Exception e) {
				
			}
			
		}while(bitsave > 0);
		
		
		sc.close();
	}
	
	private int mergeCluster(Cluster tempCluster, Cluster c1, Cluster c2, double[] newCen) {
		int mdlold1 = mdlCluster(c1)/c1.getMaxM();
		int mdlold2 = mdlCluster(c2)/c2.getMaxM();
		int mdlold = mdlold1 + mdlold2;
		
		tempCluster.setCenter(new Sequence(newCen));
		tempCluster.setCenM(newCen.length);
		tempCluster.setMinM(Math.min(c1.getMinM(), c2.getMinM()));
		tempCluster.setMaxM(Math.max(c1.getMaxM(), c2.getMaxM()));
		
		int mdlnew =mdlCluster(tempCluster)/tempCluster.getMaxM();
		int costMdl = mdlnew - mdlold;
		return costMdl;
	}

	private double[] mergeArraysInOrder(double[] part1,double[] cen, double[] part2) {
		double[] temp = new double[part1.length+cen.length+part2.length];
		int i = 0;
		for(i=0;i<part1.length;i++)
			temp[i] = part1[i];
		for(;i<cen.length+part1.length;i++)
			temp[i] = cen[i];
		for(;i<cen.length+part1.length+part2.length;i++)
			temp[i] = part2[i];
		
		return temp;
	}
	
	private Sequence nearestNeighbor(double[] ts, double[] c,boolean[] mark) {
		Sequence seq = null;
		double ed = Integer.MAX_VALUE;
		int index = -1;
		double[] temp = new double[c.length];
		for(int i=0;i<ts.length-c.length;++i) {
			boolean flag = false;
			for(int j=0;j<temp.length;++j) 
				if(mark[i+j]) { 
					flag = true;
					break;
				}
			if(flag)
				continue;
			for(int j=0;j<c.length;j++) 
				temp[j] = ts[i+j];
			
			double val = ed(c,dNorm(temp));
			
			if(val < ed) {
				ed = val;
				index = i;
				//System.out.println("index: "+index+" ed: "+ed);
			}
			
		}
		if(index < 0)
			return null;
		seq = new Sequence(temp);
		seq.setStart(index);
		return seq;
	}
	
	private double ed(double[] a, double[] b) {
		
		double temp = 0;
		
		for(int i=0;i<a.length;++i) 
			temp += Math.pow((a[i]-b[i]), 2);
		temp = Math.sqrt(temp);
		
		return temp;
	}
	
	private Cluster createCluster(double[] ts,Result result) {
		int val = result.getSequenceA().getStart();
		//System.out.println("seqA start point: "+val);
		Sequence seqA = new Sequence(Arrays.copyOfRange(ts, val, val+result.getSequenceA().getLength()));
		seqA.setStart(val);
		
		//DrawGraph.create(seqA.getSeq(), "seqA");
		
		val = result.getSequenceB().getStart();
		//System.out.println("seqB start point: "+val);
		Sequence seqB = new Sequence(Arrays.copyOfRange(ts, val, val+result.getSequenceB().getLength()));
		seqB.setStart(val);
		
		//DrawGraph.create(seqB.getSeq(), "seqB");
		Cluster c = new Cluster();
		c.addSequence(seqA);
		c.addSequence(seqB);
		c.setSize(2);
		
		double[] a = /*dNorm(seqA.getSeq())*/seqA.getSeq();
		double[] b = /*dNorm(seqB.getSeq())*/seqB.getSeq();
		double[] temp = new double[a.length];
		for(int i=0;i<a.length;i++) { 
			temp[i] = Math.round((a[i]+b[i])/2);
			//System.out.println("a: "+a[i]+" b: "+b[i]+" --> "+(a[i]+b[i])/2);
		}
		c.setCenter(new Sequence(temp));
		c.setCenM(temp.length);
		c.setMaxM(temp.length);
		c.setMinM(temp.length);
		//DrawGraph.create(temp, "center");
		
		c.setShift(new int[c.getSize()]);
		//System.out.println("cluster is created: "+c.getSize());
		return c;
	}

	/*
	 * with fixed value of b 
	 */
	private double[] dNorm(double[] seq) {
		int val = 1 << 6;
		double min = Integer.MAX_VALUE;
		double max = Integer.MIN_VALUE;
		for(double d:seq) {
			min = min>d?d:min;
			max = max<d?d:max;
		}
		double[] temp = new double[seq.length];
		for(int i=0;i<seq.length;i++) 
			temp[i] = Math.round(((seq[i] - min)/(max - min))*(val - 1)+1);
		return temp;
	}
	
	private int mdlCluster(Cluster c) {
		int mdl = 0;
		int mdlCent = mdl(c.getCenter().getSeq());
		int maxMdl = Integer.MIN_VALUE;
		int costDiff = 0;
		
		for(int i=0;i<c.getSize();++i) {
			double[] temp = dNorm(c.getSequences().get(i).getSeq())/*c.getSequences().get(i).getSeq()*/;
			
			int mdlDiff = mdl(temp,c.getCenter().getSeq());
			maxMdl = Math.max(mdlDiff, maxMdl);
			costDiff += mdlDiff;
		}
		costDiff -= maxMdl;
		mdl = mdlCent + costDiff;
		System.out.println("mdl: "+mdl);
		return mdl;
	}
	
	private int computeBitsave(Cluster c) {
		double[] seqA = dNorm(c.getSequences().get(0).getSeq())/*c.getSequences().get(0).getSeq()*/;
		double[] seqB = dNorm(c.getSequences().get(1).getSeq())/*c.getSequences().get(1).getSeq()*/;
		
		int diffA = mdl(seqA,c.getCenter().getSeq());
		int diffB = mdl(seqB,c.getCenter().getSeq());
		
		int mdlOld = (mdl(seqA)+mdl(seqB))/seqA.length;
		int mdlNew = mdl(c.getCenter().getSeq()) + Math.min(diffA, diffB)/seqA.length;
		//System.out.println("mdlOld: "+mdlOld+" mdlNew: "+mdlNew);
		return mdlNew - mdlOld;
	}
	
	private int mdl(double[] seq) {
		double min = Integer.MAX_VALUE;
		double max = Integer.MIN_VALUE;
		for(int i=0;i<seq.length;++i){
			min = min>seq[i]?seq[i]:min;
			max = max<seq[i]?seq[i]:max;
		}
		double[] temp  = new double[seq.length];
		temp = Arrays.copyOfRange(seq, 0, seq.length);
		
		return bitcost(temp,min,max);
	}
	
	private int mdl(double[] seq,double[] center) {
		double min = Integer.MAX_VALUE;
		double max = Integer.MIN_VALUE;
		double[] temp = new double[seq.length];
		for(int i=0;i<temp.length;++i){
			temp[i] = seq[i] - center[i];
			min = min>temp[i]?temp[i]:min;
			max = max<temp[i]?temp[i]:max;
		}
		
		return bitcost(seq,min,max);
	}
	
	private int bitcost(double[] seq,double min, double max) {
		for(int i=0;i<seq.length;i++) {
			seq[i] = seq[i] - min +1;
		}
		return entropy(seq);
	}
	
	private int entropy(double[] localSeq) {
		
		double entropy = 0;
		Map<Integer,Integer> values = new HashMap<Integer,Integer>();
		for(double d:localSeq) 
			if((int)d != 0)
				if(values.containsKey((int)d))
					values.put((int)d, values.get((int)d)+1);
				else
					values.put((int)d, 1);
		
		for(double d:localSeq) {
			double p = 0;
			try {
				p = (double)values.get((int)d)/localSeq.length;
			}
			catch(NullPointerException e) {
				
			}
			//System.out.println("probability: "+p+" for d: "+d+" and entropy value: "+Math.log10(p)/Math.log10(2)*p);
			if(p != 0.0)
				entropy += -p*Math.log10(p)/Math.log10(2);
			//System.out.println("entropy: "+entropy);
		}
		//final double probX =(double) 1/(localSeq.length); 
		//entropy = -localSeq.length*(probX * (Math.log10(probX)/Math.log10(2)));
		//System.out.println("SequenceDl: "+entropy*localSeq.length);
		return (int) (entropy*localSeq.length);
		
	}
	
	private double computeDL(Sequence seq) {
		double[] localSeq = seq.getSeq();
		double entropy = 0;
		Map<Integer,Integer> values = new HashMap<Integer,Integer>();
		for(double d:localSeq) 
			if((int)d != 0)
				if(values.containsKey((int)d))
					values.put((int)d, values.get((int)d)+1);
				else
					values.put((int)d, 1);
		
		for(double d:localSeq) {
			double p = 0;
			try {
				p = (double)values.get((int)d)/localSeq.length;
			}
			catch(NullPointerException e) {
				
			}
			//System.out.println("probability: "+p+" for d: "+d+" and entropy value: "+Math.log10(p)/Math.log10(2)*p);
			if(p != 0.0)
				entropy += -p*Math.log10(p)/Math.log10(2);
			//System.out.println("entropy: "+entropy);
		}
		//final double probX =(double) 1/(localSeq.length); 
		//entropy = -localSeq.length*(probX * (Math.log10(probX)/Math.log10(2)));
		System.out.println("SequenceDl: "+entropy*localSeq.length);
		return entropy*localSeq.length;
	}
	
	private double computeDL(Cluster c) {
		double centerDL = computeDL(c.getCenter()); 
		double maxOfClusterSeq = 0;
		double total = 0;
		double[] center = c.getCenter().getSeq();
		
		for(Sequence s:c.getSequences()) {
			double[] temp = s.getSeq();
			for(int i=0;i<temp.length;++i) { 
				//System.out.println("difference: "+(temp[i] - center[i]));
				temp[i] = Math.abs(temp[i] - center[i]);
				
			}
			double localDL = computeDL(new Sequence(temp));
			maxOfClusterSeq = maxOfClusterSeq>localDL?maxOfClusterSeq:localDL;
			total += localDL;
		}
		
		double finalClusterDL = centerDL - maxOfClusterSeq + total;
		//System.out.println("cluster DL: "+finalClusterDL);
		return finalClusterDL;
	}

	private void setMark(boolean[] mark, Result result) {
		int val = result.getSequenceA().getStart();
		//System.out.println("value of i: "+val);
		for(int i=val;i<val+result.getSequenceA().getLength();i++) 
			mark[i] = true;
		val = result.getSequenceB().getStart();
		//System.out.println("value of index of b: "+val);
		for(int i=val;i<val+result.getSequenceB().getLength();i++)
			mark[i] = true;
		
	}
	
}
